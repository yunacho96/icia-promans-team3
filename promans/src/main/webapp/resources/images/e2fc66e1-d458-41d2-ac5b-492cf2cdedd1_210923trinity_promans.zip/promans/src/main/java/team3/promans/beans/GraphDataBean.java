package team3.promans.beans;

import lombok.Data;

@Data
public class GraphDataBean {
	
	private int stepW;
	private int stepI;
	private int stepC;
	private int scheW;
	private int scheI;
	private int scheC;
	private int sdW;
	private int sdI;
	private int sdC;

}
