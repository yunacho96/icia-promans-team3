package team3.promans.beans;

import lombok.Data;

@Data
public class ProjectMemberBean {
	private String cpcode;
	private String prcode;
	private String userid;
	private String uname;
	private String utype;
	private String wcode;
	
}
